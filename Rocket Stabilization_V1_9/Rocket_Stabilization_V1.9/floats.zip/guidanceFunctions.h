#ifndef _GUIDANCEFUNCTIONS_H_
#define _GUIDANCEFUNCTIONS_H_

#include <Arduino.h>


#endif // _QUATERNIONFILTERS_H_

